import type {Metadata} from "next";
import "./globals.css";
export const metadata:Metadata={title:"流浪者手記",description:"私人的旅行行程、日記與花費，可跨裝置同步。",icons:{icon:"/icon-192.png"}};
export default function Layout({children}:{children:React.ReactNode}){return <html lang="zh-Hant"><body>{children}</body></html>;}
